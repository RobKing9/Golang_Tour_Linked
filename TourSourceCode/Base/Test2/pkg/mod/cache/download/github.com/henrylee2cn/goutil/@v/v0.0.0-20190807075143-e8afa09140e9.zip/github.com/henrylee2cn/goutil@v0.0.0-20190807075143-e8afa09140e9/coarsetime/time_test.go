package coarsetime

import (
	"testing"
	"time"
)

func TestTimeNow(t *testing.T) {
	time.Sleep(time.Second * 60)
}
